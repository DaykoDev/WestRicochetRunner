using UnityEngine;

public class EffectPool : MonoBehaviour
{
    [Header("Pool Settings")]
    [SerializeField] private ExplosionEffect _effectPrefab;
    [SerializeField, Min(1)] private int _initialSize = 8;
    [SerializeField, Min(1)] private int _maxSize = 30;

    private ComponentPool<ExplosionEffect> _pool;

    private void Awake()
    {
        _pool = new ComponentPool<ExplosionEffect>(_effectPrefab, transform, _initialSize, _maxSize, OnEffectCreated);
        _pool.Prewarm(_initialSize);
    }

    public ExplosionEffect Get()
    {
        return _pool.Get();
    }

    public void Release(ExplosionEffect effect)
    {
        _pool?.Release(effect);
    }

    private void OnEffectCreated(ExplosionEffect effect)
    {
        effect.SetPool(this);
    }
}