public class Barricade : Obstacle
{
}