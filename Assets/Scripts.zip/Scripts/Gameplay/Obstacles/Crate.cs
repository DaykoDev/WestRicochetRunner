public class Crate : Obstacle
{
}