public class Barrel : Obstacle
{
}