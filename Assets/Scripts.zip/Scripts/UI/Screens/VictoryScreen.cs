using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class VictoryScreen : MonoBehaviour
{
    [SerializeField] private Button _mainMenuButton;
    [SerializeField] private Button _multiplyButton;

    [Header("Reward")]
    [SerializeField] private TMP_Text _coinsText;

    public event Action MainMenuClicked;
    public event Action MultiplyClicked;

    private void OnEnable()
    {
        _mainMenuButton.onClick.AddListener(OnMainMenuClicked);
        _multiplyButton.onClick.AddListener(OnMultiplyClicked);
    }

    private void OnDisable()
    {
        _mainMenuButton.onClick.RemoveListener(OnMainMenuClicked);
        _multiplyButton.onClick.RemoveListener(OnMultiplyClicked);
    }

    public void Show()
    {
        gameObject.SetActive(true);
    }

    public void Hide()
    {
        gameObject.SetActive(false);
    }

    public void SetMultiplyAvailable(bool isAvailable)
    {
        _multiplyButton.interactable = isAvailable;
    }

    private void OnMultiplyClicked()
    {
        MultiplyClicked?.Invoke();
    }

    public void SetCollectedCoins(int coins)
    {
        if (_coinsText != null)
        {
            _coinsText.text = $"Coins: {coins}";
        }
    }

    private void OnMainMenuClicked()
    {
        MainMenuClicked?.Invoke();
    }
}