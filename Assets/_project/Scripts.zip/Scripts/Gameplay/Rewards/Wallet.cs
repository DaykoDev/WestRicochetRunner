using System;
using UnityEngine;

namespace WestRicochet.Gameplay.Rewards
{
    public class Wallet : MonoBehaviour
    {
        [SerializeField, Min(0)] private int _initialBalance;

        private bool _isInitialized;

        public event Action<int> BalanceChanged;

        public int Balance { get; private set; }

        public void Initialize(int? savedBalance = null)
        {
            if (_isInitialized)
            {
                return;
            }

            Balance = Math.Max(0, savedBalance ?? _initialBalance);
            _isInitialized = true;
            BalanceChanged?.Invoke(Balance);
        }

        public void Add(int amount)
        {
            if (amount <= 0)
            {
                return;
            }

            Balance = (int)Math.Min((long)Balance + amount, int.MaxValue);
            BalanceChanged?.Invoke(Balance);
        }

        public void Remove(int amount)
        {
            if (amount <= 0)
            {
                return;
            }

            Balance = Math.Max(0, Balance - amount);
            BalanceChanged?.Invoke(Balance);
        }

        public bool TrySpend(int amount)
        {
            if (amount <= 0 || Balance < amount)
            {
                return false;
            }

            Balance -= amount;
            BalanceChanged?.Invoke(Balance);

            return true;
        }

        public void ResetBalance()
        {
            Balance = Math.Max(0, _initialBalance);
            _isInitialized = true;

            BalanceChanged?.Invoke(Balance);
        }
    }
}