using System;
using WestRicochet.Gameplay.Rewards;
using WestRicochet.Gameplay.Upgrades;
using WestRicochet.Infrastructure;
using WestRicochet.Infrastructure.Persistence;
using WestRicochet.Meta;

namespace WestRicochet.Root
{
    public sealed class MetaComposition : IDisposable
    {
        public MetaComposition(PlayerSaveData saveData, SceneReferences sceneReferences)
        {
            Progress = new PlayerProgress(saveData);

            Settings = new SettingsService(
                saveData == null || saveData.SoundEnabled,
                saveData == null || saveData.MusicEnabled,
                saveData?.SoundVolume ?? 1f,
                saveData?.MusicVolume ?? 1f,
                sceneReferences.AudioMixer);

            Wallet = sceneReferences.Wallet;

            if (Wallet == null)
            {
                throw new InvalidOperationException("Wallet is not assigned in SceneReferences.");
            }

            Wallet.Initialize(saveData?.Coins);

            PermanentUpgradeSettings upgradeSettings = sceneReferences.PermanentUpgradeSettings;

            Upgrades = new UpgradeService(
                Progress,
                Wallet,
                upgradeSettings,
                new UpgradeCostCalculator(upgradeSettings.CostGrowth));
        }

        public PlayerProgress Progress { get; }
        public SettingsService Settings { get; }
        public Wallet Wallet { get; }
        public UpgradeService Upgrades { get; }

        public void Dispose()
        {
            Upgrades.Dispose();
        }
    }
}