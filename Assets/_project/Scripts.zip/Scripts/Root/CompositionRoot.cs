using System;
using UnityEngine;
using WestRicochet.Infrastructure.Ads;
using WestRicochet.Infrastructure.Leaderboard;
using WestRicochet.Infrastructure.Persistence;
using WestRicochet.StateMachine.States;
using YG;

namespace WestRicochet.Root
{
    public sealed class CompositionRoot : IDisposable
    {
        private readonly SceneReferences _sceneReferences;
        private readonly PlatformServicesFactory _platformFactory;

        private SaveService _saveService;

        private AdsService _adsService;
        private IAdsService _adsProvider;
        private ILeaderboardService _leaderboardService;

        private MetaComposition _meta;
        private RunComposition _run;
        private UiComposition _ui;

        private SettingsFlow _settingsFlow;
        private ProgressSaver _progressSaver;
        private GameEventBindings _eventBindings;

        private bool _isInitializing;
        private bool _isInitialized;
        private bool _isDisposed;

        public CompositionRoot(SceneReferences sceneReferences)
        {
            _sceneReferences = sceneReferences;
            _platformFactory = new PlatformServicesFactory();
        }

        public void Initialize()
        {
            if (_isDisposed || _isInitialized || _isInitializing)
            {
                return;
            }

            if (_sceneReferences == null)
            {
                Debug.LogError("CompositionRoot: SceneReferences is not assigned.");

                return;
            }

            if (_sceneReferences.TryValidate(out string errorMessage) == false)
            {
                Debug.LogError(
                    "CompositionRoot initialization failed." +
                    Environment.NewLine +
                    errorMessage,
                    _sceneReferences);

                return;
            }

            _isInitializing = true;

            _saveService = new SaveService(_platformFactory.CreateProgressStorage());

            _saveService.Load(OnProgressLoaded);
        }

        public void FlushSave()
        {
            if (_isDisposed)
            {
                return;
            }

            if (_isInitialized)
            {
                _progressSaver.SaveAndFlush();
            }
            else
            {
                _saveService?.Flush();
            }
        }

        public void Dispose()
        {
            if (_isDisposed)
            {
                return;
            }

            _isDisposed = true;

            if (_isInitialized)
            {
                _progressSaver?.SaveAndFlush();
            }
            else
            {
                _saveService?.Flush();
            }

            _eventBindings?.Dispose();
            _settingsFlow?.Dispose();
            _progressSaver?.Dispose();

            _ui?.Dispose();
            _run?.Dispose();
            _meta?.Dispose();

            _adsService?.Dispose();

            if (_adsProvider is IDisposable disposableAds)
            {
                disposableAds.Dispose();
            }

            if (_leaderboardService is IDisposable disposableLeaderboard)
            {
                disposableLeaderboard.Dispose();
            }

            _saveService?.Dispose();

            _isInitialized = false;
            _isInitializing = false;
        }

        public void ResetAllSave()
        {
            if (_isDisposed || _isInitialized == false)
            {
                Debug.LogWarning("Cannot reset save before initialization is completed.");
                return;
            }

            _meta.Progress.ResetProgress();
            _meta.Wallet.ResetBalance();

            _progressSaver.SaveAndFlush();
        }

        private void OnProgressLoaded(PlayerSaveData saveData)
        {
            if (_isDisposed || _isInitialized)
            {
                return;
            }

            _isInitializing = false;

            try
            {
                _meta = new MetaComposition(saveData, _sceneReferences);

                _adsProvider = _platformFactory.CreateAdsProvider();

                _leaderboardService = _platformFactory.CreateLeaderboardProvider(_sceneReferences.LeaderboardYG);

                _adsService = new AdsService(_adsProvider, _sceneReferences.AdsConfig);

                _run = new RunComposition(
                    _sceneReferences,
                    _meta,
                    _adsService);

                _ui = new UiComposition(
                    _sceneReferences,
                    _meta,
                    _run,
                    _leaderboardService);

                _settingsFlow = new SettingsFlow(
                    _ui.Settings,
                    _run.PausedState,
                    _run.GameFlow);

                _progressSaver = new ProgressSaver(
                    _saveService,
                    _meta.Progress,
                    _meta.Wallet,
                    _meta.Settings,
                    _run.MainMenuState,
                    _run.RunState,
                    _run.MenuCoins,
                    _run.VictoryMultiplier);

                _eventBindings = new GameEventBindings(
                    _leaderboardService,
                    _meta,
                    _run,
                    _ui,
                    _settingsFlow);

                _isInitialized = true;

                _run.StateMachine.Enter<BootstrapState>();
            }
            catch (Exception exception)
            {
                Debug.LogException(exception, _sceneReferences);

                Dispose();
            }
        }
    }
}